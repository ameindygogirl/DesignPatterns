
public interface Guitar
{
	public void playGuitar();
}
