
public class PutGuitarOnFire implements Solo 
{
	public void playSolo()
	{
		System.out.println(" puts his guitar on the ground and lights it on fire!  The audience is mesmerized!");
	}
}
