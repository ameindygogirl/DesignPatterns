
public class GameCharacterYoung extends GameCharacter {

	public GameCharacterYoung()
	{
		character = "Angus Young";
		solo = new SmashesTheGuitar();
	}
}
