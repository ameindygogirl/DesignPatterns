
public class FenderTelecaster implements Guitar
{	
	public void playGuitar()
	{
		System.out.println(" plays a beautiful lick on his Fender Telecaster");
	}
}