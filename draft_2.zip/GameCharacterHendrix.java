
public class GameCharacterHendrix extends GameCharacter
{
	public GameCharacterHendrix()
	{
		character = "Jimi Hendrix";
		solo = new PutGuitarOnFire();
	}
}