
public class SmashesTheGuitar implements Solo
{
	public void playSolo()
	{
		System.out.println(" smashes his guitar into the bits!  The audience goes wild!");
	}
}
