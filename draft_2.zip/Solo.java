public interface Solo 
{
	public void playSolo();
}
