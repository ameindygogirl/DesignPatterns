public class GibsonSG implements Guitar
{
	public void playGuitar()
	{
		System.out.println(" shreds that Gibson SG like a mutha!");
	}
}
