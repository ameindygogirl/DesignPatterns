
public class JumpsOffTheStage implements Solo
{
	public void playSolo()
	{
		System.out.println(" leaps from the stage!  He plays an excellent riff while crowd surfing!");
	}
}
