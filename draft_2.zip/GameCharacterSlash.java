
public class GameCharacterSlash extends GameCharacter
{
	public GameCharacterSlash()
	{
		character = "Slash";
		solo = new JumpsOffTheStage();
	}
}
