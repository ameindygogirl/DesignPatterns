
public class GibsonFlyingV implements Guitar 
{
	public void playGuitar()
	{
		System.out.println("'s Gibson Flying V is radiating the audience!");
	}
}
