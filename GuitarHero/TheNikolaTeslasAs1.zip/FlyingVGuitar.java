/*
Team: The Nikola Teslas
Members: Ryan Babcock, Stacy Carlson, and Laura Humphreys 
*/
public class FlyingVGuitar implements Guitar {

	@Override
	public void playGuitar() {
		System.out.println(" plays a Gibson Flying V.");

	}

}
