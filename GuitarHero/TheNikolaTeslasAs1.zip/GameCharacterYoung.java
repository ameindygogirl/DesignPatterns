/*
Team: The Nikola Teslas
Members: Ryan Babcock, Stacy Carlson, and Laura Humphreys 
*/
public class GameCharacterYoung extends GameCharacter{

	public GameCharacterYoung()
	{
		super("Angus Young", new FlyingVGuitar(), new SmashSolo());
	}
}
