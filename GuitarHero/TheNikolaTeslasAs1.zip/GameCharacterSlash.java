/*
Team: The Nikola Teslas
Members: Ryan Babcock, Stacy Carlson, and Laura Humphreys 
*/
public class GameCharacterSlash extends GameCharacter{

	public GameCharacterSlash()
	{
		super("Slash", new GibsonSGGuitar(), new FireSolo());
	}
}
