/*
Team: The Nikola Teslas
Members: Ryan Babcock, Stacy Carlson, and Laura Humphreys 
*/
public class GameCharacterHendrix extends GameCharacter{
	
	public GameCharacterHendrix()
	{
		super("Jimi Hendrix", new TelecasterGuitar(), new JumpSolo());
	}
}
