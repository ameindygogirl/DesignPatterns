/*
Team: The Nikola Teslas
Members: Ryan Babcock, Stacy Carlson, and Laura Humphreys 
*/
public class SmashSolo implements Solo {

	@Override
	public void playSolo() {
		System.out.println(" smashes his guitar!");

	}

}
