/*
Team: The Nikola Teslas
Members: Ryan Babcock, Stacy Carlson, and Laura Humphreys 
*/
public class TelecasterGuitar implements Guitar {

	@Override
	public void playGuitar() {
		System.out.println(" plays a Fender Telecaster.");

	}

}
