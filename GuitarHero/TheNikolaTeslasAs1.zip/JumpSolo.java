/*
Team: The Nikola Teslas
Members: Ryan Babcock, Stacy Carlson, and Laura Humphreys 
*/
public class JumpSolo implements Solo {

	@Override
	public void playSolo() {
		System.out.println(" jumps off the stage!");

	}

}
